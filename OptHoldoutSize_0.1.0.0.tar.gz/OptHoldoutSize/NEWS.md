# News for package OptHoldoutSize

# OptHoldoutSize version 0.1.0

This version includes a reference to our manuscript on arXiv, which covers details of the methods implemented here.

We made some changes to the vignette on model comparisons so that the figures convey slightly more information.

