# News for package OptHoldoutSize

# OptHoldoutSize version 0.1.0

This version includes a reference to our manuscript on arXiv, which covers details of the methods implemented here.

We made some changes to the vignette on model comparisons so that the figures convey slightly more information.

## OptHoldoutSize version 0.1.1

This version attempts to correct some problems with R markdown leading to vignettes being rendered wrongly. 

Vignettes are now rendered as PDF, not HTML, since HTML rendering did not consistently format symbols.

